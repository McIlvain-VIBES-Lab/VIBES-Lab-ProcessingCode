function d=v_magn(v)
% calculates the magnitude of vectors defined in v : n by 3 matrix

d = sqrt(sum(v.^2,2));


