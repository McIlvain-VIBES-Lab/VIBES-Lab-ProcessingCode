function point = intersectPlaneLine(plane, line)
%INTERSECTPLANELINE return intersection between a plane and a line
%
%   PT = intersectPlaneSphere(PLANE, LINE) return the intersection point of
%   the given line and the given plane.
%   PLANE : [x0 y0 z0 dx1 dy1 dz1 dx2 dy2 dz2]
%   LINE :  [x0 y0 z0 dx dy dz]
%   PT :    [XI YI ZI]
%   
%
%
%  Songbai Ji (6/23/2006). Bug fixed; also allow one plane, many lines; 
% many planes one line; or N planes and N lines configuration in the input.
%   ---------
%
%   author : David Legland 
%   INRA - TPV URPOI - BIA IMASTE
%   created the 17/02/2005.
%

%   HISTORY

if size(plane, 1) == 1; %one plane possible many lines
    plane = repmat(plane, size(line,1), 1);
elseif size(line,1) == 1; % one line and many planes
    line = repmat(line, size(plane,1),1);
elseif (size(plane,1) ~= size(line,1)) ; % N planes and M lines, not allowed for now.
    error('input size not correct, either one/many plane and many/one line, or same # of planes and lines!');
end
    
% plane normal
n = cross(plane(:,4:6), plane(:, 7:9), 2);

point = zeros(1,3);
% test if line and plane are parallel
II = find(abs(dot(n, line(:,4:6), 2))<1e-14);
if ~isempty(II)
    point(II,:) = [NaN NaN NaN];
end
% 
% % test if line and plane are parallel
% if abs(dot(n, line(:,4:6), 2))<1e-14
%     point = [NaN NaN NaN];
%     return;
% end

% difference between origins of plane and line
dp = plane(:,1:3) - line(:,1:3);

% relative position of intersection on line
% Should be Array multiply, original file had a bug. (songbai ji
% 6/23/2006).
t = dot(n, dp, 2)./dot(n, line(:,4:6), 2);

% compute coord of intersection point
% point = line(:,1:3) + t*line(:,4:6);
%% NOTE: original m file had a bug (in the above line).  It should be
%% corrected as follows.  (Songbai Ji 6/23/2006).
point = line(:,1:3) + repmat(t,1,3).*line(:,4:6);

