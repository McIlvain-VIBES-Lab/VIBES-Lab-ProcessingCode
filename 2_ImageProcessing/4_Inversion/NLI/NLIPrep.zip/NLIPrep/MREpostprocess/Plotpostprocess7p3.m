
function Plotpostprocess7p3(f,svfig)


if(nargin==0)
    [f]=getfilename('Conv file to plot? ','*.prop.01.RE.convinfo');
end
stm=f(1:end-20);

mshind=load([stm '.meshind']);
fid=fopen([stm '.reconind']);
rcnindtxt=fscanf(fid,'%c');
fclose(fid)
rcnindtxt=rcnindtxt(rcnindtxt=='T'|rcnindtxt=='F');
rcnind=rcnindtxt=='T';

np=3;
nfig=0;

for ip=1:np
    ps=sprintf('%2.2i',ip);
    for jj=1:2
        if(jj==1)
            RI='RE';
            RI_t='Real';
        elseif(jj==2)
            RI='IM';
            RI_t='Imag';
        end
    
        if(rcnind(2*(ip-1)+jj))           
                
            fn=[stm '.prop.' ps '.' RI '.convinfo'];
            conv=load(fn);
            nitr=conv(end,1);
            nfig=nfig+1;
            h(nfig)=figure;
            figinfo(nfig,1)=ip;
            figinfo(nfig,2)=jj;
            errorbar(1:nitr,conv(:,2),conv(:,3))
            hold on
            plot(1:nitr,conv(:,5),'c.-',1:nitr,conv(:,7),'r.-') % 5th and 95th percentiles
            plot(1:nitr,conv(:,4),'c.-',1:nitr,conv(:,8),'r.-') % min and max values            
            xlabel('iteration');
            ylabel('value');
            title([RI_t ' - Property ' int2str(ip)]);
            legend('Mean',[int2str(5) '%'],[int2str(95) '%'],'min','max')

        end
    
    end
end


%% Prompt to save Figures
if(nargin<2)
    svfig=input('Format to save figures <jpg,fig,tif etc, default = no save>  >>','s');
end

if(isempty(svfig))
    disp('No figures Saved')
else
    disp(['Saving Figures as ' svfig ' images '])
    for ii=1:nfig
        H=h(ii);
        % Generate Filetag
        if(figinfo(ii,2)==1) % Real
            ftag=['_conv_prop' sprintf('%2.2i',figinfo(ii,1)) '_Re'];
        elseif(figinfo(ii,2)==2) % Imag
            ftag=['_conv_prop' sprintf('%2.2i',figinfo(ii,1)) '_Im'];
        end
        savename=[stm ftag '.' svfig];
        saveas(H,savename,svfig)
    end
        
end



